first_number = 1+1+5
print(first_number)
second_number = 105+10
print(second_number)

total = first_number + second_number

print(total)
