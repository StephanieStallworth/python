hello = "Hello world!"

print(hello)
